# Supported baseline decision, 2026-11-12

The maintainer approved retaining 2026.1.5.1 / Java 21 in this review session.
This deliberately drops 233 / Java 17; older IDEs need an earlier plugin release.
The supported range is 261.27258.136–263.*. This is a compatibility tradeoff,
not a claim that older builds are technically impossible.

Options investigated against released binaries and source:

- The 233 `NavigationService` lacks the current request-based `navigate`
  descriptor. Its direct `Navigatable` and list overloads are internal.
- The 233 public data-context overload exists, but the released implementation
  constructs `OpenFileDescriptor` and calls synchronous `navigate` under EDT
  `blockingContext`. It does not supply the 261 suspending editor-loading path.
  A plain custom data context also triggers its async-context diagnostic.
  No typing-preserving prototype is claimed for this option.
- Public synchronous `FileEditorManager.openFile` exists on 233. Reintroducing
  it requires fresh regression evidence because lost chat keys motivated the
  asynchronous implementation; compilation is insufficient.
- Version-specific builds are feasible: a Java 17 artifact with a 233 editor
  implementation, legacy terminal hooks, bounded descriptor, and separate
  verifier/native jobs. The 233 terminal lacks the modern startup-options
  connector hook. This avoids unavailable symbols but does not itself solve
  the 233 editor focus regression. No legacy build has been implemented/tested.

The chosen strategy uses the public 261 request API and one modern artifact,
avoiding an unproven 233 fallback and a second build's testing/release cost.
WebStorm 262 stays supported and retains its native/live regression jobs.

Sources: JetBrains' [multiple-version guidance](https://plugins.jetbrains.com/docs/intellij/build-number-ranges.html#targeting-multiple-ide-versions),
[dependency helpers](https://plugins.jetbrains.com/docs/intellij/tools-intellij-platform-gradle-plugin-dependencies-extension.html),
and [released 233 navigation implementation](https://github.com/JetBrains/intellij-community/blob/idea/233.11799.241/platform/lang-impl/src/com/intellij/platform/ide/navigation/impl/IdeNavigationService.kt).
The adjacent SDK inspection records establish signatures and annotations from
installed binaries rather than upstream master.

The maintainer supplied the failing Marketplace target: IntelliJ IDEA
**2026.1.5.1**, report date **2026-11-09 09:56** (timezone unspecified),
Verifier **1.410**, verdict **Compatible**, **3 internal usages**
(`FileEditorManagerEx.openFile`, `FileEditorOpenOptions.withRequestFocus`,
`FileEditorOpenOptions`) and **12 scheduled-for-removal usages**. The complete
original report and uploaded ZIP checksum remain unavailable. Fresh verification
reproduces the target but cannot establish identity with the previously uploaded
ZIP. Issue #18 remains partial, including proxy/customizer migrations and
remaining scheduled-for-removal/deprecated findings.
